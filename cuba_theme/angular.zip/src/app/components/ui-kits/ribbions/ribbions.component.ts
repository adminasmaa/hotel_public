import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ribbions',
  templateUrl: './ribbions.component.html',
  styleUrls: ['./ribbions.component.scss']
})
export class RibbionsComponent implements OnInit {

  constructor() { }

  ngOnInit() { }

}
