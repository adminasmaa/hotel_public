import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-creative',
  templateUrl: './creative.component.html',
  styleUrls: ['./creative.component.scss']
})
export class CreativeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
