<footer class="footer">
	  <div class="container-fluid">
		    <div class="row">
			      <div class="col-md-12 footer-copyright text-center">
			        	<p class="mb-0">Copyright <?php echo e(date('Y')); ?> © Cuba theme by pixelstrap  </p>
			      </div>
		    </div>
	  </div>
</footer><?php /**PATH /home/ekta/Documents/0 - Themeforest - Themes/Cuba Theme/Cuba/resources/views/layouts/simple/footer.blade.php ENDPATH**/ ?>